in mlplibrary file, comment the "block from print" line.
the main file is mlplibrary.
load the pictures in mnist file. it opens the .zip file (it contains pictures).
